const Discord = require(`discord.js`)
var colour = require ("colour")
const client = new  Discord.Client({disableEveryone: true}); //your bot client 
 var general ="675951464056619020" //replace this code to your channel id

 var channel = general

let y=process.openStdin() //allows you to type on the console

console.log("ready!")

y.addListener("data", res => {  //this sendsnthe message from the console 
let x = res.toString().trim().split(/ +/g)
let message = client.channels.cache.get(channel)
 message.send(x.join(""))

});


client.on("message", async message => {
    if(message.channel.type === "dm") return;
    console.log(`[${message.channel.name}];`+ `${message.channel}` + "\n")
    console.log(`[${message.author.username}]:`+ `${message.author}` +":" + message.content)
})


client.login("NjY1MzIyODQzMzU3MzE1MDcy.Xp6VkQ.-CtXFE8x3YFJuJjsmyPZiwNFFE8")
