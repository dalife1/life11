const Discord = module.require("discord.js");

module.exports.run = async (client, message, args) =>{
    //insert code here
    }
    
    module.exports.help = {
        name: "", //This is the name of the command that will be put after the prefix (`${prefix}command name`)
        description: "", //Description for the command
        usage:"", //example for the command
        aliases: [""] //shortcut for command (if theres no shortcut aliases, please insert the name of the command in the alias section)
    }

