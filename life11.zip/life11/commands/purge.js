const Discord = module.require("discord.js");

module.exports.run = async (client, message, args) =>{
    //insert code here

    if(message.member.hasPermission("BAN_MEMBERS"))
    
    amount = args[0]
    if(isNaN(amount))return message.channel.send("The amount specified is not a number")
    if(amount > 100)return message.channel.send("You cannot delete more than 100 messages")
    if(amount <1)return message.channel.send("Please delete atleast more that 1 message")

    
    message.channel.fetch({limit: amount})
    .then(() => message.channel.bulkDelete(amount))
    //.then(() => message.channel.send(`${amount} messages deleted!`)).then(m => m.delete({timeout: 5000}))  //this sends a message
    .setTitle(`${amount} messages deleted!`)

    message.channel.send(embed).then(m => m.delete({timeout: 5000})) //this sends an embedded message



    }
    
    module.exports.help = {
        name: "purge", //This is the name of the command that will be put after the prefix (`${prefix}command name`)
        description: "deletes the amount of messages that you input", //Description for the command
        usage:"purge <amount>", //example for the command
        aliases: ["p"] //shortcut for command (if theres no shortcut aliases, please insert the name of the command in the alias section)
    }