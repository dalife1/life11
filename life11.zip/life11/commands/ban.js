const Discord = module.require("discord.js");

module.exports.run = async (client, message, args) =>{
{  if(message.mentions.users.first().id === "502053447982645268")
  return message.channel.send("cant ban my brainless god")


    
   let member = message.mentions.members.first();
    message.channel.send(`${message.author.username} the kid got banned
    
     ${member.username}`)
    .then(member.ban())
    }
}




module.exports.help = {
    name: "ban", //This is the name of the command that will be put after the prefix (`${prefix}command name`)
    description: "deletes the amount of messages that you input", //Description for the command
    usage:"purge <amount>", //example for the command
    aliases: ["b"] //shortcut for command (if theres no shortcut aliases, please insert the name of the command in the alias section)
}