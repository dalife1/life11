const prefix = "."; //set your own prefix here


//modules requirement
const Discord = require('discord.js');
const fs = require("fs");

const client = new Discord.Client({disableEveryone: true});

client.commands = new Discord.Collection(); //creates a collection for the commands
client.aliases = new Discord.Collection();  //creates a collection for *shortcuts* of the command

fs.readdir("./commands/", (err, files) =>{
    if(err) console.error(err);

    let jsfiles = files.filter(f => f.split(".").pop() === "js") //filters the files that ends with .js
    if(jsfiles.length <= 0){
        console.log("No commands to load!")
        return
    }
    console.log(`Loading ${jsfiles.length} commands!`); //shows the amount of commands loaded

    jsfiles.forEach((f, i) =>{
        let props = require(`./commands/${f}`);
        //console.log(`${i + 1}: ${f} loaded!`); //remove the '//'before the console.log if you want it to show each commands in the console log
        client.commands.set(props.help.name, props);

        props.help.aliases.forEach(alias =>{
            client.aliases.set(alias, props.help.name)
        })

    })
});

//Here comes the client/bot's code

client.on('ready', async () =>{  
    console.log(`${client.user.tag} is online`)
    client.user.setActivity(`${prefix} `);//replace [insert main command here] with your command name
});



//welcomes the user when joined into the server

client.on(`guildMemberAdd`, member =>{
    let joinchannelid = "685921654429450487";//insert the channel id to which you want the welcome message to be sent
    member.guild.channels.get(`${joinchannelid}`).send(`Welcome ${member.user} to the server!`) //Sends a welcome message to the channel with the id from JOINCHANNELID
})

client.on('message', async message =>{
    if(message.channel.type === "dm") return //if message comes from dm
   
   


    let messageArray = message.content.split(" ")
    let command = messageArray[0]
    let args = messageArray.slice(1);

    if(!command.startsWith(prefix)) return

    let cmd = client.commands.get(command.slice(prefix.length)) || client.commands.get(client.aliases.get(command.slice(prefix.length)))
    if(cmd) cmd.run(client,message,args)



(process.env.PORT)

client.on('message', message => {
	console.log(message.content);
});
 



git 
 



})

client.login("NjY1MzIyODQzMzU3MzE1MDcy.Xp8LUA.5P8_wrD_XlGfQNkYke0AHb6-WVg")
client.login(process.env.TOKEN)

